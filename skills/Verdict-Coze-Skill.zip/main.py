
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from l0_engine.atomizer import atomize
from l0_engine.noise_engine.pipeline import filter_noise as _filter_noise, is_reporter_glue


def filter_noise(text: str) -> dict:
    if not text or not text.strip():
        return {'error': 'text is required'}
    if len(text) > 3000:
        text = text[:3000]

    claims = atomize(text)
    clean = _filter_noise(claims, text)

    results = []
    for c in clean:
        results.append({
            'claim_text': c.get('claim_text', ''),
            'noise_score': c.get('noise_score', 0),
            'hollowness': round(c.get('structural_hollowness', 0), 4),
            'causal_risk': round(c.get('causal_risk', 0), 4),
        })

    total = len(claims)
    clean_count = len(clean)
    noise_count = total - clean_count

    return {
        'total_claims': total,
        'clean_claims': clean_count,
        'noise_filtered': noise_count,
        'noise_rate': round(noise_count / max(total, 1), 4),
        'results': results,
    }


def check_glue(text: str) -> dict:
    return {'is_glue': is_reporter_glue(text), 'text': text}
