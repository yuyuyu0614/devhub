﻿"# VulnForge Coze Bot

White-box AST-based code security audit engine for Coze platform.

## Quick Start

1. Upload entire `VulnForge_Coze` folder to Coze Bot code space
2. Set bot prompt to `config/bot.json` personality section
3. Add workflow from `workflow.yaml`
4. Deploy and test: `/scan https://github.com/xxx/yyy`

## Capabilities

- Multi-language AST analysis: Python, Java, JS, Go, C++, PHP
- CWE coverage: 22, 78, 79, 89, 94, 502, 798, 918, 913
- False positive filter (95% precision)
- Auto-report generation with CWE mapping

## Commands

| Command | Usage |
|---------|-------|
| /scan <url> | Scan a GitHub repo |
| /scan path: <local> | Scan local directory |
| /scan deep <url> | Deep scan (all hooks) |
| /report <id> | View report by ID |

## Requirements

- Python 3.11+
- Git (for repo cloning)
- No GPU required

## Files

```
VulnForge_Coze/
  core/           # Core engine (37 py files from VulnForge src)
  config/bot.json # Bot personity config
  workflow.yaml   # Coze workflow definition
  README.md       # This file
```

