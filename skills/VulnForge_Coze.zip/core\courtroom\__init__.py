"""VulTrial — multi-agent mock courtroom for vulnerability adjudication.

Based on: VulTrial (SMU/GovTech/Sydney University, arXiv 2505.10961)
Four roles: Prosecutor, Defender, Judge, Jury.
Multi-round debate produces a jury verdict with confidence scoring (+25 pts).
"""
