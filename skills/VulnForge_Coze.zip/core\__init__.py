# VulnForge — Phase 1 Core Modules
# All modules independently testable.
# Canonical Python: D:/python/python.exe
