﻿"# CWE Reference for VulnForge

## CWE-22: Path Traversal
- Detection: file operations with user-controlled paths
- Examples: open(user_input), read(path_variable)
- Severity: high

## CWE-78: OS Command Injection
- Detection: os.system, subprocess.call with tainted input
- Examples: os.system(cmd + user_input), subprocess.Popen(user_data)
- Severity: critical

## CWE-89: SQL Injection
- Detection: raw SQL with string concatenation
- Examples: cursor.execute("SELECT * FROM users WHERE id=" + uid)
- Severity: critical

## CWE-94: Code Injection
- Detection: exec, eval, compile with dynamic content
- Examples: eval(user_code), exec(f"print({data})")
- Severity: critical

## CWE-502: Deserialization
- Detection: pickle.loads, yaml.load, ObjectInputStream
- Examples: pickle.loads(user_bytes), yaml.load(untrusted_data)
- Severity: high

## CWE-798: Hardcoded Credentials
- Detection: hardcoded passwords, API keys, tokens
- Examples: password = "admin123", API_KEY = "sk-xxx"
- Severity: high

