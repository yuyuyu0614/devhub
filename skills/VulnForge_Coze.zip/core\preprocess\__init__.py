"""VulnForge preprocess — external tool integrations (Semgrep, truffleHog)."""
