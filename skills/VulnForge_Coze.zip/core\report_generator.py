"""SRC Report Generator — 补天/HackerOne/TSRC multi-platform export.

Generates submission-ready vulnerability reports with CWE classification,
confidence scoring, PoC generation, and multi-platform formatting.
"""

import json
import re
from datetime import datetime
from pathlib import Path

PLATFORM_TEMPLATES = {
    "butian": {
        "name": "补天SRC",
        "fields": ["漏洞标题", "漏洞类型(CWE)", "危害等级", "漏洞URL/位置", "漏洞描述", "复现步骤", "修复建议", "置信度"],
    },
    "hackerone": {
        "name": "HackerOne",
        "fields": ["Title", "CWE", "Severity", "Endpoint", "Description", "Steps to Reproduce", "Remediation", "Confidence"],
    },
    "tsrc": {
        "name": "腾讯TSRC",
        "fields": ["漏洞标题", "漏洞类型", "危害等级", "影响URL", "漏洞详情", "复现步骤", "修复方案", "自评等级"],
    },
    "360src": {
        "name": "360SRC",
        "fields": ["标题", "类型", "等级", "漏洞地址", "详细描述", "PoC", "修复建议", "可信度"],
    },
}


def _extract_danger_line(snippet):
    lines = snippet.split('\\n')
    for line in lines:
        if '>>>' in line:
            return line.replace('>>>', '').strip()
    return snippet[:200]


def generate_poc(hook):
    cwe = hook.get('cwe_id', 'CWE-0')
    func_name = hook.get('func_name', 'unknown')
    dang_line = _extract_danger_line(hook.get('snippet', ''))
    code_block = '```\\n' + dang_line + '\\n```'
    
    templates = {
        'CWE-89': 'SQL Injection PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nGET /' + func_name + "?id=1' OR '1'='1 HTTP/1.1\\n```",
        'CWE-78': 'Command Injection PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nPOST /' + func_name + '\\ncmd=; cat /etc/passwd\\n```',
        'CWE-22': 'Path Traversal PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nGET /' + func_name + '?file=../../../etc/passwd\\n```',
        'CWE-94': 'Code Injection PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack: inject malicious code via ' + func_name + '()',
        'CWE-502': 'Deserialization PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack: send malicious pickled object',
        'CWE-918': 'SSRF PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nGET /' + func_name + '?url=http://169.254.169.254/\\n```',
        'CWE-79': 'XSS PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nGET /' + func_name + '?name=<script>alert(1)</script>\\n```',
        'CWE-798': 'Hardcoded Credentials\\n\\nVulnerable code:\\n' + code_block + '\\n\\nRisk: credentials exposed in source code',
        'CWE-601': 'Open Redirect PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack:\\n```\\nGET /' + func_name + '?next=https://evil.com\\n```',
        'CWE-611': 'XXE PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nAttack: send malicious XML with external entity',
    }
    return templates.get(cwe, 'PoC\\n\\nVulnerable code:\\n' + code_block + '\\n\\nManual verification required.')


def build_report(findings, platform='butian', repo_url=''):
    tmpl = PLATFORM_TEMPLATES.get(platform, PLATFORM_TEMPLATES['butian'])
    lines = []
    lines.append('# VulnForge Security Audit Report')
    lines.append('')
    lines.append(f'- Platform: {tmpl["name"]}')
    lines.append(f'- Generated: {datetime.now().isoformat()}')
    lines.append(f'- Target: {repo_url}')
    lines.append(f'- Total Findings: {len(findings)}')
    lines.append('')
    lines.append('---')
    lines.append('')
    
    by_sev = {'critical': [], 'high': [], 'medium': [], 'low': []}
    for f in findings:
        sev = f.get('severity', 'medium')
        if sev in by_sev:
            by_sev[sev].append(f)
    
    idx = 1
    for sev in ['critical', 'high', 'medium', 'low']:
        for f in by_sev[sev]:
            title = f.get('title', 'Untitled')
            cwe = f.get('cwe_id', 'CWE-0')
            desc = f.get('description', '')
            confidence = f.get('confidence', 50)
            remediation = f.get('remediation', 'Review and fix')
            file_path = f.get('file_path', '')
            
            lines.append(f'## #{idx} [{sev.upper()}] {cwe}: {title}')
            lines.append('')
            lines.append(f'| Field | Value |')
            lines.append(f'|-------|-------|')
            lines.append(f'| CWE | {cwe} |')
            lines.append(f'| Severity | {sev} |')
            lines.append(f'| Location | {file_path} |')
            lines.append(f'| Confidence | {confidence}% |')
            lines.append(f'| Description | {desc} |')
            lines.append(f'| Remediation | {remediation} |')
            lines.append('')
            poc = generate_poc(f)
            lines.append(poc)
            lines.append('')
            lines.append('---')
            lines.append('')
            idx += 1
    
    lines.append('## Summary')
    lines.append('')
    cwe_counts = {}
    for f in findings:
        cwe = f.get('cwe_id', 'CWE-0')
        cwe_counts[cwe] = cwe_counts.get(cwe, 0) + 1
    for cwe, cnt in sorted(cwe_counts.items()):
        lines.append(f'- {cwe}: {cnt}')
    
    return '\\n'.join(lines)


def export_report(findings, output_path, platform='butian', repo_url=''):
    report = build_report(findings, platform, repo_url)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)
    return output_path


def export_json(findings, output_path):
    export = {
        'meta': {
            'tool': 'VulnForge',
            'version': '1.3.0',
            'timestamp': datetime.now().isoformat(),
            'total_findings': len(findings),
        },
        'findings': []
    }
    for f in findings:
        export['findings'].append({
            'cwe': f.get('cwe_id', 'CWE-0'),
            'severity': f.get('severity', 'info'),
            'title': f.get('title', ''),
            'description': f.get('description', ''),
            'file': f.get('file_path', ''),
            'line': f.get('line_start', 0),
            'confidence': f.get('confidence', 50),
            'poc': generate_poc(f),
            'remediation': f.get('remediation', ''),
            'function': f.get('func_name', ''),
        })
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(export, f, ensure_ascii=False, indent=2)
    return output_path
