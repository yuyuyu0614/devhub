﻿"""VulnForge Coze Entry Point - Headless scan engine for Coze Bot integration."""
import sys, os, json, tempfile, subprocess, shutil, hashlib
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

from feature_extractor import extract_directory
from false_positive_filter import FalsePositiveFilter
from cwe_classifier import classify_hook
from report_generator import generate_markdown_report

class VulnForgeCoze:
    def __init__(self):
        self.fp_filter = FalsePositiveFilter()
    
    def scan_repo(self, repo_url: str, scan_type: str = "quick") -> dict:
        """Main scan entry - clone repo, extract hooks, filter, classify, report."""
        report_id = hashlib.md5(repo_url.encode()).hexdigest()[:12]
        scan_dir = Path(tempfile.gettempdir()) / f"vf_scan_{report_id}"
        
        try:
            if scan_dir.exists():
                shutil.rmtree(scan_dir)
            subprocess.run(["git", "clone", "--depth", "1", repo_url, str(scan_dir)], 
                          capture_output=True, text=True, timeout=300)
            
            hooks = extract_directory(str(scan_dir))
            findings = []
            for h in hooks:
                if not self.fp_filter.is_false_positive(h):
                    cwe = classify_hook(h)
                    if cwe:
                        h["cwe"] = cwe
                        findings.append(h)
            
            report = generate_markdown_report(report_id, repo_url, findings, scan_type)
            shutil.rmtree(scan_dir, ignore_errors=True)
            
            return {
                "report_id": report_id,
                "status": "completed",
                "total_hooks": len(hooks),
                "findings": len(findings),
                "report": report
            }
        except Exception as e:
            shutil.rmtree(scan_dir, ignore_errors=True)
            return {"report_id": report_id, "status": "failed", "error": str(e)}
    
    def scan_local(self, local_path: str, scan_type: str = "deep") -> dict:
        """Scan a local directory without git clone."""
        report_id = hashlib.md5(local_path.encode()).hexdigest()[:12]
        try:
            hooks = extract_directory(local_path)
            findings = []
            for h in hooks:
                if not self.fp_filter.is_false_positive(h):
                    cwe = classify_hook(h)
                    if cwe:
                        h["cwe"] = cwe
                        findings.append(h)
            report = generate_markdown_report(report_id, local_path, findings, scan_type)
            return {"report_id": report_id, "status": "completed", "total_hooks": len(hooks), "findings": len(findings), "report": report}
        except Exception as e:
            return {"report_id": report_id, "status": "failed", "error": str(e)}

engine = VulnForgeCoze()

