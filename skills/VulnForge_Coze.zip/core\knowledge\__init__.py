"""VulnForge knowledge base — vulnerability pattern extraction and retrieval."""
